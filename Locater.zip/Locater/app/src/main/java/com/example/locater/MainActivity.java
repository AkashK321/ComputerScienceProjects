package com.example.locater;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.tasks.OnSuccessListener;

public class MainActivity extends AppCompatActivity implements ConnectionCallbacks, OnConnectionFailedListener {

    private FusedLocationProviderClient fusedLocationClient;
    protected Location lastLocation;
    private AddressResultReceiver resultReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    protected void startIntentService() {
        Intent intent = new Intent(this, FetchAddressIntentService.class);
        intent.putExtra(FetchAddressIntentService.Constants.RECEIVER, resultReceiver);
        intent.putExtra(FetchAddressIntentService.Constants.LOCATION_DATA_EXTRA, lastLocation);
        startService(intent);
    }

    public void locate (View view) {

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {

                        Location lastKnownLocation = location;

                        if (lastKnownLocation == null){
                            return;
                        }

                        /*
                        if (!Geocoder.isPresent()) {
                            Toast.makeText(MainActivity.this, R.string.no_geocoder_available, Toast.LENGTH_LONG).show();
                            return;
                        }
                        add
                         */
                        
                        startIntentService();
                        //updateUI();

                    }
/*
                    private void updateUI() {
                        resultReceiver.displayAddressOutput();
                    }

 */
                });

    }

    class AddressResultReceiver extends ResultReceiver {

        /**
         * Create a new ResultReceive to receive results.  Your
         * {@link #onReceiveResult} method will be called from the thread running
         * <var>handler</var> if given, or from an arbitrary thread if null.
         *
         * @param handler
         */
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        String addressOutput = "1";

        private void displayAddressOutput() {
            TextView textView = findViewById(R.id.address);
            textView.setText(addressOutput);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData){

            if (resultData == null){
                return;
            }
            addressOutput = resultData.getString(FetchAddressIntentService.Constants.RESULT_DATA_KEY);
            if (addressOutput == null){
                addressOutput = "";
            }
            displayAddressOutput();

            /*
            if (resultCode == FetchAddressIntentService.Constants.SUCCESS_RESULT){


            }

             */
        }


    }


}
